document.addEventListener('DOMContentLoaded', () => {
    const loginLink = document.getElementById('signup-link');
    const signupLink = document.getElementById('login-link');

    if (loginLink) {
        loginLink.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = 'signup.html';
        });
    }

    if (signupLink) {
        signupLink.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = 'index.html';
        });
    }

    // Handle form submissions if needed
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Perform login logic here
            window.location.href = 'dashboard.html';
        });
    }

    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Perform signup logic here
            window.location.href = 'index.html';
        });
    }
});
